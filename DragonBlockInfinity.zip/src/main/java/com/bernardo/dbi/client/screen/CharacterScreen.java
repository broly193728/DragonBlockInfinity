package com.bernardo.dbi.client.screen;

import com.bernardo.dbi.race.Race;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nullable;
import java.util.Objects;

@OnlyIn(Dist.CLIENT)
@SuppressWarnings("null")
public class CharacterScreen extends Screen {

    private static final ResourceLocation MENU_BACKGROUND = new ResourceLocation("dbi", "textures/gui/menu/menu_base.png");
    private static final ResourceLocation BUTTON_LEFT = new ResourceLocation("dbi", "textures/gui/button_seta_esquerda.png");
    private static final ResourceLocation BUTTON_RIGHT = new ResourceLocation("dbi", "textures/gui/button_seta_direita.png");

    private static final int MENU_WIDTH = 300;
    private static final int MENU_HEIGHT = 200;

    private @Nullable Player player;
    private Race.RaceType currentRace = Race.RaceType.Humano;

    // Botões para raças
    private @Nullable Button leftButton;
    private @Nullable Button rightButton;

    // Botões pequenos para customização
    private @Nullable Button hairButton;
    private @Nullable Button noseButton;
    private @Nullable Button mouthButton;

    public CharacterScreen() {
        super(Component.literal("Character Menu"));
        this.player = Minecraft.getInstance().player;
    }

    @Override
    protected void init() {
        super.init();

        int menuX = (this.width - MENU_WIDTH) / 2;
        int menuY = (this.height - MENU_HEIGHT) / 2;

        // Botões para navegar raças (setas pequenas)
        this.leftButton = this.addRenderableWidget(Button.builder(Component.empty(), button -> {
            // Raça anterior
            Race.RaceType[] races = Race.RaceType.values();
            int currentIndex = currentRace.ordinal();
            currentRace = races[(currentIndex - 1 + races.length) % races.length];
        }).bounds(menuX + 100, menuY + 150, 8, 8).build());

        this.rightButton = this.addRenderableWidget(Button.builder(Component.empty(), button -> {
            // Raça próxima
            Race.RaceType[] races = Race.RaceType.values();
            int currentIndex = currentRace.ordinal();
            currentRace = races[(currentIndex + 1) % races.length];
        }).bounds(menuX + 192, menuY + 150, 8, 8).build());

        // Botões de customização (lado direito, pequenos)
        this.hairButton = this.addRenderableWidget(Button.builder(Component.literal("C"), button -> {
            // Placeholder para cabelo
        }).bounds(menuX + MENU_WIDTH - 60, menuY + 50, 20, 20).build());

        this.noseButton = this.addRenderableWidget(Button.builder(Component.literal("N"), button -> {
            // Placeholder para nariz
        }).bounds(menuX + MENU_WIDTH - 35, menuY + 50, 20, 20).build());

        this.mouthButton = this.addRenderableWidget(Button.builder(Component.literal("B"), button -> {
            // Placeholder para boca
        }).bounds(menuX + MENU_WIDTH - 60, menuY + 75, 20, 20).build());
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        int menuX = (this.width - MENU_WIDTH) / 2;
        int menuY = (this.height - MENU_HEIGHT) / 2;

        // Renderizar fundo do menu centralizado
        guiGraphics.blit(MENU_BACKGROUND, menuX, menuY, 0, 0, MENU_WIDTH, MENU_HEIGHT, MENU_WIDTH, MENU_HEIGHT);

        // Renderizar modelo do jogador no lado esquerdo
        renderPlayerModel(guiGraphics, menuX + 50, menuY + 100);

        // Renderizar textura da raça atual
        renderRaceTexture(guiGraphics, currentRace, menuX + 118, menuY + 50);

        // Renderizar nome da raça
        String raceName = currentRace.name().replace("_", " ");
        guiGraphics.drawString(Minecraft.getInstance().font, raceName, menuX + 150 - Minecraft.getInstance().font.width(raceName) / 2, menuY + 120, 0xFFFFFF);

        // Renderizar setas sobre os botões
        if (leftButton != null) {
            guiGraphics.blit(BUTTON_LEFT, leftButton.getX(), leftButton.getY(), 0, 0, leftButton.getWidth(), leftButton.getHeight(), leftButton.getWidth(), leftButton.getHeight());
        }
        if (rightButton != null) {
            guiGraphics.blit(BUTTON_RIGHT, rightButton.getX(), rightButton.getY(), 0, 0, rightButton.getWidth(), rightButton.getHeight(), rightButton.getWidth(), rightButton.getHeight());
        }

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    private void renderPlayerModel(GuiGraphics guiGraphics, int x, int y) {
        if (player != null) {
            PoseStack poseStack = guiGraphics.pose();
            EntityRenderDispatcher dispatcher = Minecraft.getInstance().getEntityRenderDispatcher();
            // Simplificado: renderizar entidade pequena
            poseStack.pushPose();
            poseStack.translate(x, y, 100);
            poseStack.scale(0.8f, 0.8f, 0.8f);
            dispatcher.render(player, 0, 0, 0, 0, 1, poseStack, Minecraft.getInstance().renderBuffers().bufferSource(), 15728880);
            poseStack.popPose();
        }
    }

    private void renderRaceTexture(GuiGraphics guiGraphics, Race.RaceType race, int x, int y) {
        String textureName = race.name().toLowerCase();
        if (race == Race.RaceType.Half_Sayajin) {
            textureName = "fsayajin";
        }
        ResourceLocation texture = new ResourceLocation("dbi", "textures/player/" + textureName + ".png");
        guiGraphics.blit(texture, x, y, 0, 0, 64, 64, 64, 64); // Renderizar textura pequena
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}